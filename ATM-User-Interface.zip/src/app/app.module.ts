import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { BalanceComponent } from './balance/balance.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { DepositComponent } from './deposit/deposit.component';
import { DepositCoinsComponent } from './deposit-coins/deposit-coins.component';
import { DepositNotesComponent } from './deposit-notes/deposit-notes.component';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: 'balance',component:BalanceComponent },
  { path: 'deposit',component:DepositComponent },
  { path: 'withdraw',component:WithdrawComponent }
];



@NgModule({
  declarations: [
    AppComponent,
    BalanceComponent,
    WithdrawComponent,
    DepositComponent,
    DepositCoinsComponent,
    DepositNotesComponent
  ],
  imports: [
    RouterModule.forRoot(routes),
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }


