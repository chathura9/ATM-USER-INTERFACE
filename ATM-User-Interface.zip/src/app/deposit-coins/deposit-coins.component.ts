import { Component } from '@angular/core';

@Component({
  selector: 'app-deposit-coins',
  templateUrl: './deposit-coins.component.html',
  styleUrls: ['./deposit-coins.component.css']
})
export class DepositCoinsComponent {

}
