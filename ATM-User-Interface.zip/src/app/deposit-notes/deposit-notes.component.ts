import { Component } from '@angular/core';

@Component({
  selector: 'app-deposit-notes',
  templateUrl: './deposit-notes.component.html',
  styleUrls: ['./deposit-notes.component.css']
})
export class DepositNotesComponent {

}
